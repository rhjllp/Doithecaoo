const form = document.getElementById('cardForm');
const result = document.getElementById('result');
const historyDiv = document.getElementById('history');

form.addEventListener('submit', function (e) {
  e.preventDefault();
  const type = document.getElementById('cardType').value;
  const amount = document.getElementById('cardAmount').value;
  const code = document.getElementById('cardCode').value;
  const seri = document.getElementById('cardSeri').value;

  const data = { type, amount, code, seri, time: new Date().toLocaleString() };

  // Hiển thị kết quả giả lập
  result.innerText = "Thẻ đã được gửi! Đang xử lý...";

  // Lưu lịch sử
  let logs = JSON.parse(localStorage.getItem('cardHistory') || '[]');
  logs.push(data);
  localStorage.setItem('cardHistory', JSON.stringify(logs));

  showHistory();
  form.reset();
});

function showHistory() {
  let logs = JSON.parse(localStorage.getItem('cardHistory') || '[]');
  historyDiv.innerHTML = '<h3>Lịch sử gửi thẻ:</h3>';
  logs.slice().reverse().forEach(log => {
    historyDiv.innerHTML += `<div>- [${log.time}] ${log.type} - ${log.amount}đ - Mã: ${log.code} - Seri: ${log.seri}</div>`;
  });
}

showHistory();
